<!--

js

-->
<script>
    $('.soro').DataTable({
        paging: false,
        info: false,
        searching: false,
        order: []
    });
        $('.table_responsive').DataTable({
            paging: false,
            info: false,
            searching: false,
            responsive: {
                details: true
                // display: $.fn.dataTable.Responsive.display.modal()
            },
            order: []
        });
</script>
</body>

</html>
