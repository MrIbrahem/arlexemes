<?php

include __DIR__ . '/adminer.php';
