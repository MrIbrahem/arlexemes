<?php

require __DIR__ . "/main.php";

?>
<div class="wrapper" style="background-color: rgb(241, 244, 253);">
    <div class="wrapper_box">
        <h3> اللغة: <a href="https://www.wikidata.org/entity/Q13955" target="_blank" class="text-primary">العربية</a>
        </h3>
        <h3> الفئة: <a href="https://www.wikidata.org/entity/Q24905" target="_blank" class="text-primary">فعل</a></h3>
    </div>
    <div class="wrapper_box">
        <div><strong>اسم مصدر:</strong> اِحْتِسَاب </div>
        <div><strong>اِسْم الْمَفْعُول:</strong> مُحْتَسَب </div>
        <div><strong>اِسْم الْفَاعِل:</strong><a href="https://www.wikidata.org/entity/L1490749" target="_blank">
                مُحْتَسِب </a></div>
    </div>
</div>

<style>
    .wrapper {
        display: flex;
        flex-wrap: wrap;
    }

    .wrapper_box {
        flex: 1 1 50%;
        display: flex;
        gap: 0.5rem;
        justify-content: center;
        align-items: center;
    }

    @media (max-width: 767.98px) {
        .wrapper_box {
            flex: 1 1 100%;
        }
    }
</style>
<div class="container my-4">
    <div class="d-flex align-items-center justify-content-center">
        <div class="list-group list-group-flush">
            <span find-label-both="true" no-cache="true" class="list-group-item list-group-item-action" find-label="Q805">Q805</span>
            <span find-label-both="true" no-cache="true" class="list-group-item list-group-item-action" find-label="Q8555555555555555505">Q8555555555555555505</span>
            <span find-label-both="true" no-cache="true" class="list-group-item list-group-item-action" find-label="P31">P31</span>
            <span find-label-both="true" no-cache="true" class="list-group-item list-group-item-action" find-label="P13116">P13116</span>
            <span find-label-both="true" no-cache="true" class="list-group-item list-group-item-action" find-label="L3">L3</span>
        </div>
    </div>
    <div id="urls_load">
        الوصلات:
    </div>
    <script src="/static/js/lex/find_labels.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', async () => {
            await find_labels();
        });
    </script>
    <?php

    require __DIR__ . "/footer.php";

    ?>
