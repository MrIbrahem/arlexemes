<?php

require __DIR__ . "/main.php";

?>
<style>
    /* حد عمودي بين الإطارين */
    .border-between {
        border-left: 3px solid #ccc;
    }

    /* إذا الوضع عمودي نغير الحد ليكون أفقي */
    .flex-column .border-between {
        border-left: none;
        border-bottom: 3px solid #ccc;
    }
</style>
<div class="container my-4">
    <div class="d-flex align-items-center justify-content-center">
        <div class="row col-md-10 border rounded">
            <div class="max-w-3xl mx-auto rounded-lg shadow-md p-6 bg-light-subtle">
                <div class="row m-6 p-3">
                    <div class="col-md-10 col-sm-10 mb-2 mb-md-0">
                        <span class="text-2xl font-bold text-center h2">
                            مقارنة المفردات:
                        </span>
                        <span id="qids_span">
                        </span>
                    </div>
                    <div class="col-md-2 col-sm-2 mb-2 mb-md-0">
                        <a href="#" target="_blank" id="sparql_url" class="btn btn-outline-primary disabled" role="button">
                            <span class="d-flex text-center align-items-center">
                                <span class="query"></span>&nbsp;
                                استعلام
                            </span>
                        </a>
                        <!-- <span id="query_time" class="ms-3"></span> -->
                    </div>
                </div>
                <hr>
                <div id="loading" class="text-center text- hidden">
                    <div class="spinner-border spinner-border-sm" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    جارٍ التحميل (بطيء)...<br>أي مقترح لتحسين الاستعلام مرحب به
                </div>
                <div id="tables_container"></div>
            </div>
        </div>
    </div>
</div>
<script src="/static/js/lex/find_labels.js"></script>
<script src="/static/js/lexemes/queries.js"></script>
<script src="/static/js/lexemes/compare.js"></script>
<script src="/static/js/toggleView_compare.js"></script>

<script>
    async function start() {
        // ---
        let qids = get_param_from_window_location("qids", "") || "";
        // ---
        qids = qids ? qids.split(",") : [];
        // ---
        const container = document.getElementById("qids_span");
        if (container && qids.length > 0) {
            container.innerHTML = "(" + qids.map((qid, index) => {
                const separator = index === 0 ? "" : " - ";
                return `${separator}<a href="https://www.wikidata.org/entity/${qid}" target="_blank">
                        <span class="fs-5">
                            <span find-label="${qid}" find-label-both="true">${qid}</span>
                        </span>
                    </a>`;
            }).join('') + ")";
        } else if (container) {
            container.textContent = "()"; // حالة عدم وجود QIDs
        }

        // --- استدعاء دالة التحميل ---
        await load_compare(qids);

    }

    document.addEventListener('DOMContentLoaded', () => start());
</script>

<?php

require __DIR__ . "/footer.php";

?>
